import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Crown, Settings, Save, RotateCcw } from "lucide-react";
import type { RoleWithPermissions, Permission } from "@shared/schema";

export default function RolePermissions() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [selectedRoleId, setSelectedRoleId] = useState("");
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>([]);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: roles } = useQuery({
    queryKey: ["/api/roles"],
    enabled: isAuthenticated,
  });

  const { data: allPermissions } = useQuery({
    queryKey: ["/api/permissions"],
    enabled: isAuthenticated,
  });

  const { data: selectedRole } = useQuery({
    queryKey: ["/api/roles", selectedRoleId],
    enabled: isAuthenticated && !!selectedRoleId,
  });

  // Update selected permissions when role changes
  useEffect(() => {
    if (selectedRole) {
      setSelectedPermissions(selectedRole.permissions.map((p: Permission) => p.id));
    } else {
      setSelectedPermissions([]);
    }
  }, [selectedRole]);

  const updateRolePermissionsMutation = useMutation({
    mutationFn: async (data: { roleId: string; permissionIds: string[] }) => {
      await apiRequest("PUT", `/api/roles/${data.roleId}/permissions`, {
        permissionIds: data.permissionIds,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/roles"] });
      toast({
        title: "Success",
        description: "Role permissions updated successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update role permissions. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handlePermissionToggle = (permissionId: string) => {
    setSelectedPermissions(prev => 
      prev.includes(permissionId)
        ? prev.filter(id => id !== permissionId)
        : [...prev, permissionId]
    );
  };

  const handleSelectAll = () => {
    if (selectedPermissions.length === allPermissions?.length) {
      setSelectedPermissions([]);
    } else {
      setSelectedPermissions(allPermissions?.map((p: Permission) => p.id) || []);
    }
  };

  const handleSave = () => {
    if (!selectedRoleId) {
      toast({
        title: "Error",
        description: "Please select a role first.",
        variant: "destructive",
      });
      return;
    }
    updateRolePermissionsMutation.mutate({
      roleId: selectedRoleId,
      permissionIds: selectedPermissions,
    });
  };

  const handleReset = () => {
    if (selectedRole) {
      setSelectedPermissions(selectedRole.permissions.map((p: Permission) => p.id));
    }
  };

  const getRoleIcon = (roleName: string) => {
    const name = roleName.toLowerCase();
    if (name.includes("admin")) {
      return <Crown className="w-5 h-5 text-primary" />;
    }
    return <Settings className="w-5 h-5 text-blue-600 dark:text-blue-400" />;
  };

  const getRoleColor = (roleName: string) => {
    const name = roleName.toLowerCase();
    if (name.includes("admin")) {
      return "bg-primary/10";
    }
    return "bg-blue-100 dark:bg-blue-900/20";
  };

  // Group permissions by category
  const permissionsByCategory = allPermissions?.reduce((acc: { [key: string]: Permission[] }, permission: Permission) => {
    if (!acc[permission.category]) {
      acc[permission.category] = [];
    }
    acc[permission.category].push(permission);
    return acc;
  }, {}) || {};

  if (isLoading || !isAuthenticated) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="flex pt-16">
        <Sidebar />
        <main className="flex-1 ml-64 p-6">
          <div className="mb-8">
            <Card>
              <div className="px-6 py-4 border-b border-border">
                <div>
                  <h3 className="text-lg font-semibold text-foreground">Role-Permission Assignment</h3>
                  <p className="text-sm text-muted-foreground mt-1">Assign and manage permissions for roles</p>
                </div>
              </div>
              
              <CardContent className="p-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Role Selection */}
                  <div>
                    <Label className="text-sm font-medium text-foreground mb-3 block">Select Role</Label>
                    <Select value={selectedRoleId} onValueChange={setSelectedRoleId}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Choose a role..." />
                      </SelectTrigger>
                      <SelectContent>
                        {roles?.map((role: RoleWithPermissions) => (
                          <SelectItem key={role.id} value={role.id}>
                            {role.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    {/* Selected Role Info */}
                    {selectedRole && (
                      <div className="mt-4 p-4 bg-muted rounded-lg">
                        <div className="flex items-center space-x-3 mb-3">
                          <div className={`w-8 h-8 ${getRoleColor(selectedRole.name)} rounded-lg flex items-center justify-center`}>
                            {getRoleIcon(selectedRole.name)}
                          </div>
                          <div>
                            <h4 className="font-medium text-foreground">{selectedRole.name}</h4>
                            <p className="text-sm text-muted-foreground">{selectedRole.description || "No description"}</p>
                          </div>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          <p><strong>Current Permissions:</strong> {selectedRole.permissions.length} of {allPermissions?.length || 0}</p>
                          <p><strong>Assigned Users:</strong> {selectedRole.userCount}</p>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  {/* Permission Assignment */}
                  <div>
                    <Label className="text-sm font-medium text-foreground mb-3 block">Available Permissions</Label>
                    <div className="border border-border rounded-lg max-h-80 overflow-y-auto">
                      <div className="p-3 border-b border-border bg-muted">
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="select-all"
                            checked={selectedPermissions.length === allPermissions?.length && allPermissions?.length > 0}
                            onCheckedChange={handleSelectAll}
                          />
                          <Label htmlFor="select-all" className="text-sm font-medium text-foreground">
                            Select All
                          </Label>
                        </div>
                      </div>
                      
                      {/* Permission Categories */}
                      {Object.entries(permissionsByCategory).map(([category, permissions]) => (
                        <div key={category} className="p-3 border-b border-border last:border-b-0">
                          <h5 className="text-sm font-medium text-foreground mb-3">{category}</h5>
                          <div className="space-y-2 ml-4">
                            {permissions.map((permission: Permission) => (
                              <div key={permission.id} className="flex items-center space-x-3">
                                <Checkbox
                                  id={permission.id}
                                  checked={selectedPermissions.includes(permission.id)}
                                  onCheckedChange={() => handlePermissionToggle(permission.id)}
                                />
                                <Label htmlFor={permission.id} className="text-sm text-foreground">
                                  {permission.name}
                                </Label>
                                <span className="text-xs text-muted-foreground">
                                  {permission.description || "No description"}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                      
                      {Object.keys(permissionsByCategory).length === 0 && (
                        <div className="p-6 text-center text-muted-foreground">
                          No permissions available. Create some permissions first.
                        </div>
                      )}
                    </div>
                    
                    <div className="flex justify-end space-x-3 mt-4">
                      <Button variant="outline" onClick={handleReset} disabled={!selectedRole}>
                        <RotateCcw className="w-4 h-4 mr-2" />
                        Reset
                      </Button>
                      <Button 
                        onClick={handleSave} 
                        disabled={!selectedRoleId || updateRolePermissionsMutation.isPending}
                      >
                        <Save className="w-4 h-4 mr-2" />
                        {updateRolePermissionsMutation.isPending ? "Saving..." : "Save Changes"}
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
