import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import { Card, CardContent } from "@/components/ui/card";
import { Users, UserCog, Key, Shield } from "lucide-react";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats"],
    enabled: isAuthenticated,
  });

  if (isLoading || !isAuthenticated) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="flex pt-16">
        <Sidebar />
        <main className="flex-1 ml-64 p-6">
          <div className="mb-8">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-foreground mb-2">Dashboard Overview</h2>
              <p className="text-muted-foreground">Manage roles, permissions, and user access control</p>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <Users className="w-6 h-6 text-primary" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-muted-foreground">Total Users</p>
                      <p className="text-2xl font-bold text-foreground">
                        {statsLoading ? "..." : stats?.totalUsers || 0}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="p-3 bg-green-100 dark:bg-green-900/20 rounded-lg">
                      <UserCog className="w-6 h-6 text-green-600 dark:text-green-400" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-muted-foreground">Active Roles</p>
                      <p className="text-2xl font-bold text-foreground">
                        {statsLoading ? "..." : stats?.totalRoles || 0}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="p-3 bg-orange-100 dark:bg-orange-900/20 rounded-lg">
                      <Key className="w-6 h-6 text-orange-600 dark:text-orange-400" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-muted-foreground">Permissions</p>
                      <p className="text-2xl font-bold text-foreground">
                        {statsLoading ? "..." : stats?.totalPermissions || 0}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="p-3 bg-red-100 dark:bg-red-900/20 rounded-lg">
                      <Shield className="w-6 h-6 text-red-600 dark:text-red-400" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-muted-foreground">Security Score</p>
                      <p className="text-2xl font-bold text-foreground">94%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="border-2 border-dashed border-border hover:border-primary/50 transition-colors cursor-pointer">
                    <CardContent className="p-6 text-center">
                      <Key className="w-8 h-8 text-primary mx-auto mb-2" />
                      <h4 className="font-medium text-foreground mb-1">Create Permission</h4>
                      <p className="text-sm text-muted-foreground">Add new system permission</p>
                    </CardContent>
                  </Card>
                  
                  <Card className="border-2 border-dashed border-border hover:border-primary/50 transition-colors cursor-pointer">
                    <CardContent className="p-6 text-center">
                      <UserCog className="w-8 h-8 text-primary mx-auto mb-2" />
                      <h4 className="font-medium text-foreground mb-1">Create Role</h4>
                      <p className="text-sm text-muted-foreground">Define new user role</p>
                    </CardContent>
                  </Card>
                  
                  <Card className="border-2 border-dashed border-border hover:border-primary/50 transition-colors cursor-pointer">
                    <CardContent className="p-6 text-center">
                      <Users className="w-8 h-8 text-primary mx-auto mb-2" />
                      <h4 className="font-medium text-foreground mb-1">Assign Roles</h4>
                      <p className="text-sm text-muted-foreground">Manage user assignments</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
