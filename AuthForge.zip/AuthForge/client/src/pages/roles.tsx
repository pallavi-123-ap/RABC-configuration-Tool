import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import CreateRoleModal from "@/components/modals/create-role-modal";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Plus, Crown, Edit, Trash2, Settings } from "lucide-react";
import type { RoleWithPermissions } from "@shared/schema";

export default function Roles() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [createModalOpen, setCreateModalOpen] = useState(false);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: roles, isLoading: rolesLoading } = useQuery({
    queryKey: ["/api/roles"],
    enabled: isAuthenticated,
  });

  const { data: allPermissions } = useQuery({
    queryKey: ["/api/permissions"],
    enabled: isAuthenticated,
  });

  const deleteRoleMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/roles/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/roles"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Success",
        description: "Role deleted successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete role. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDeleteRole = (id: string) => {
    if (confirm("Are you sure you want to delete this role?")) {
      deleteRoleMutation.mutate(id);
    }
  };

  const getRoleIcon = (roleName: string) => {
    const name = roleName.toLowerCase();
    if (name.includes("admin")) {
      return <Crown className="w-5 h-5 text-primary" />;
    }
    if (name.includes("editor")) {
      return <Edit className="w-5 h-5 text-green-600 dark:text-green-400" />;
    }
    return <Settings className="w-5 h-5 text-blue-600 dark:text-blue-400" />;
  };

  const getRoleColor = (roleName: string) => {
    const name = roleName.toLowerCase();
    if (name.includes("admin")) {
      return "bg-primary/10";
    }
    if (name.includes("editor")) {
      return "bg-green-100 dark:bg-green-900/20";
    }
    return "bg-blue-100 dark:bg-blue-900/20";
  };

  const calculatePermissionPercentage = (role: RoleWithPermissions) => {
    if (!allPermissions || allPermissions.length === 0) return 0;
    return Math.round((role.permissions.length / allPermissions.length) * 100);
  };

  if (isLoading || !isAuthenticated) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="flex pt-16">
        <Sidebar />
        <main className="flex-1 ml-64 p-6">
          <div className="mb-8">
            <Card>
              <div className="px-6 py-4 border-b border-border">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground">Roles Management</h3>
                    <p className="text-sm text-muted-foreground mt-1">Create and manage user roles</p>
                  </div>
                  <Button onClick={() => setCreateModalOpen(true)} className="flex items-center space-x-2">
                    <Plus className="w-4 h-4" />
                    <span>Add Role</span>
                  </Button>
                </div>
              </div>
              
              <CardContent className="p-6">
                {/* Roles Grid */}
                {rolesLoading ? (
                  <div className="text-center py-8">Loading roles...</div>
                ) : !roles || roles.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No roles found. Create your first role to get started.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {roles.map((role: RoleWithPermissions) => (
                      <Card key={role.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex items-center space-x-3">
                              <div className={`w-10 h-10 ${getRoleColor(role.name)} rounded-lg flex items-center justify-center`}>
                                {getRoleIcon(role.name)}
                              </div>
                              <div>
                                <h4 className="font-semibold text-foreground">{role.name}</h4>
                                <p className="text-sm text-muted-foreground">{role.description || "No description"}</p>
                              </div>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Button variant="ghost" size="sm" className="p-1">
                                <Edit className="w-4 h-4 text-muted-foreground" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="p-1 text-destructive hover:text-destructive"
                                onClick={() => handleDeleteRole(role.id)}
                                disabled={deleteRoleMutation.isPending}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                          
                          <div className="mb-4">
                            <div className="flex items-center justify-between text-sm mb-2">
                              <span className="text-muted-foreground">Permissions</span>
                              <span className="font-medium text-foreground">
                                {role.permissions.length}/{allPermissions?.length || 0}
                              </span>
                            </div>
                            <Progress value={calculatePermissionPercentage(role)} className="h-2" />
                          </div>
                          
                          <div className="mb-4">
                            <p className="text-sm text-muted-foreground mb-2">Assigned Users</p>
                            <div className="flex items-center space-x-2">
                              <span className="text-sm font-medium text-foreground">
                                {role.userCount} user{role.userCount !== 1 ? 's' : ''}
                              </span>
                            </div>
                          </div>
                          
                          <Button 
                            variant="outline" 
                            className="w-full"
                            onClick={() => {
                              // Navigate to role permissions page
                              window.location.href = `/role-permissions?role=${role.id}`;
                            }}
                          >
                            Manage Permissions
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>

      <CreateRoleModal 
        open={createModalOpen} 
        onOpenChange={setCreateModalOpen} 
      />
    </div>
  );
}
