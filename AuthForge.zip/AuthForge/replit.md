# RBAC Configuration Tool

## Overview

This is a full-stack Role-Based Access Control (RBAC) configuration tool built for internal use. The application allows administrators to create and manage permissions, roles, and their relationships through a modern web interface. It's designed as a comprehensive system for managing user access controls in large applications.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: React Query (TanStack Query) for server state management
- **Routing**: Wouter for client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express server
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: Replit Auth integration with OpenID Connect
- **Session Management**: Express sessions with PostgreSQL store

### Database Design
- **Database**: PostgreSQL (configured for Neon serverless)
- **Schema**: Comprehensive RBAC schema with proper relationships
- **Tables**: 
  - Users (for authentication)
  - Permissions (individual access rights)
  - Roles (groups of permissions)
  - Role-Permission mappings (many-to-many)
  - User-Role assignments (many-to-many)
  - Sessions (for auth state)

## Key Components

### Authentication System
- **Provider**: Replit Auth with OpenID Connect
- **Session Storage**: PostgreSQL-backed sessions using connect-pg-simple
- **Security**: HTTP-only cookies with secure settings
- **User Management**: Automatic user creation/updates on login

### Permission Management
- **CRUD Operations**: Full create, read, update, delete for permissions
- **Categorization**: Permissions organized by categories
- **Validation**: Zod schemas for data validation
- **Search & Filter**: Real-time search and category filtering

### Role Management
- **CRUD Operations**: Complete role lifecycle management
- **Permission Assignment**: Visual interface for attaching permissions to roles
- **Role Visualization**: Progress indicators showing permission coverage
- **Bulk Operations**: Efficient batch permission assignments

### Data Validation
- **Schema Validation**: Drizzle-Zod integration for runtime type safety
- **Form Validation**: React Hook Form with Zod resolvers
- **API Validation**: Server-side input validation on all endpoints

## Data Flow

### Authentication Flow
1. User accesses protected route
2. Middleware checks for valid session
3. If unauthenticated, redirects to Replit OAuth
4. On successful auth, creates/updates user record
5. Establishes secure session with PostgreSQL storage

### Permission Management Flow
1. Admin creates/edits permissions through form interface
2. Client validates input using Zod schemas
3. API endpoint validates and stores in database
4. Real-time UI updates via React Query cache invalidation

### Role-Permission Assignment Flow
1. Admin selects role from dropdown
2. System loads current permissions for that role
3. Admin toggles permission checkboxes
4. Batch API calls handle permission assignments/removals
5. UI reflects changes immediately with optimistic updates

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for serverless environments
- **drizzle-orm**: Type-safe database ORM with migration support
- **express**: Web application framework
- **react**: Frontend library with hooks
- **@tanstack/react-query**: Server state management
- **zod**: Runtime type validation

### Authentication Dependencies
- **openid-client**: OpenID Connect client implementation
- **passport**: Authentication middleware
- **connect-pg-simple**: PostgreSQL session store
- **express-session**: Session management middleware

### UI Dependencies
- **@radix-ui/***: Accessible UI component primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe CSS class variants
- **react-hook-form**: Performant forms with validation

## Deployment Strategy

### Development Environment
- **Build Tool**: Vite with React plugin and TypeScript support
- **Hot Reload**: Vite HMR for instant development feedback
- **Error Handling**: Runtime error overlay for debugging
- **Database**: Drizzle migrations for schema management

### Production Considerations
- **Build Process**: Vite builds client, esbuild bundles server
- **Static Assets**: Client built to `dist/public` directory
- **Server Bundle**: ESM format with external dependencies
- **Environment Variables**: Required DATABASE_URL and auth configs
- **Session Security**: Secure cookies with proper domain settings

### Database Management
- **Migrations**: Drizzle Kit for schema versioning
- **Connection Pooling**: Neon serverless connection pooling
- **Schema Definition**: Centralized in `shared/schema.ts`
- **Type Safety**: Generated types for all database operations

The application follows a traditional MVC pattern with modern tooling, emphasizing type safety, developer experience, and secure authentication. The architecture supports both development and production environments with appropriate build processes and security considerations.